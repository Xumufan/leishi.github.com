
function save_ByAlpha_LogisticSparseGroupLasso_Priority(method, dataset, JND, theta, output_var_array, alpha_array)

group_id = ['JND=',num2str(JND*100),'_theta=',num2str(theta*100)];
eval(['load ../output/', dataset, '_priority/raw/',method,'_SGL_',group_id,';']);

dirName = ['../output/', dataset, '_priority/feature/',method,'/',group_id];
if exist(dirName, 'dir') == 0;
    mkdir(dirName);
end;
        
num = cell(length(output_var_array), length(alpha_array));
num_aboveJND = cell(length(output_var_array), length(alpha_array));
minPE = cell(length(output_var_array), length(alpha_array));
minPE_debiased = cell(length(output_var_array), length(alpha_array));
subgraphQ = cell(length(output_var_array), length(alpha_array));
group_size = cell(length(output_var_array), length(alpha_array));
delta_theta = cell(length(output_var_array), length(alpha_array));
visibility = cell(length(output_var_array), length(alpha_array));

for k = 1:length(output_var_array);
    output_var = output_var_array{k};
    
    for i = 1:length(alpha_array);        
        alpha = alpha_array{i};
        alpha_string = num2str(alpha * 100);               
        
        B = strcat('B_', output_var, '_', alpha_string);     
        FitInfo = strcat('FitInfo_', output_var, '_', alpha_string);    
        %eval(['B_var=',B,'(:,',num2str(selected_lambda_index{i}),');']);
        
        eval(['B_index=',FitInfo,'.IndexMinDeviance;']);
        eval(['B_index_debiased=',FitInfo,'.IndexMinDeviance_debiased;']);
        eval(['B_var=',B,'(:,B_index_debiased);']);
        
        [B_r,~, B_v] = find(B_var);               
        
        % output selected edge features: (src_index, dst_index,
        % parameter_weight)
        fileName = [dirName,'/',[upper(output_var(1)) strrep(output_var(2:end),'_Class','')],'_',num2str(alpha, '%1.1f'),'.txt'];
        fid = fopen(fileName,'wt');
        
        for t = 1:length(B_v);
            index = current_edge_index(1, B_r(t, 1));
            src = srcIndexMap(index,1);
            dst = dstIndexMap(index,1);
            fprintf(fid,'%d,%d,%f \n',src,dst,B_v(t,1));
        end;
        fclose(fid);
        
        % output selected edge feature original values: (src_index,
        % dst_index, parameter_weight, average, variance, original_values...)
        fileName = [dirName,'/',[upper(output_var(1)) strrep(output_var(2:end),'_Class','')],'_',num2str(alpha),'_feature.csv'];
        fid = fopen(fileName,'wt');
        
        B_ratio = zeros(size(B_v));
        for t = 1:length(B_v);
            index = current_edge_index(1, B_r(t, 1));
            src = srcIndexMap(index,1);
            dst = dstIndexMap(index,1);
            feature = edge_feature(:,index);
            avg = mean(feature(:));
            std = std2(feature);
            B_ratio(t,1) = CCI_Ratio(1,index);
            fprintf(fid,'%d,%d,%d,%f,%f,%f,%f',src,dst,index,B_v(t,1),B_ratio(t,1),avg,std);
            for m = 1:length(feature);
                fprintf(fid,',%d',feature(m,1));
            end;
            fprintf(fid,'\n');
        end;
        fclose(fid);                               
        
        if ~isempty(B_v);
            co = corr(log(abs(B_v(:,1))), B_ratio(:,1));
            disp(['correlation (alpha=',num2str(alpha),'): ',num2str(co)]);
        end;
        
        num{k,i} = length(B_v);
        num_aboveJND{k,i} = sum(B_ratio(:,1)>=JND);
        eval(['minPE{k,i}=',FitInfo,'.Deviance(1,',num2str(B_index),');']);
        eval(['minPE_debiased{k,i}=',FitInfo,'.Deviance_debiased(1,',num2str(B_index_debiased),');']);
        eval(['subgraphQ{k,i}=',FitInfo,'.subgraphQ(1,',num2str(B_index_debiased),');']);
        eval(['group_size{k,i}=',FitInfo,'.Group_Size(:,',num2str(B_index_debiased),');']);
        eval(['delta_theta{k,i}=',FitInfo,'.Delta_Theta(:,',num2str(B_index_debiased),');']);
        eval(['visibility{k,i}=',FitInfo,'.visibility(1,',num2str(B_index_debiased),');']);
       
%         eval([output_var,'_num_',alpha_string,'=',num2str(length(B_v)),';']);
%         eval([output_var,'_num_aboveJND_',alpha_string,'=sum(B_ratio(:,1)>=',num2str(JND),');']);               
%         eval(['minPE{k,i}=',FitInfo,'.Deviance(1,',num2str(B_index),');']);
        
     end;
end;

%disp(['Recording num for JND=',num2str(JND_ext),', theta=',num2str(theta_ext)]);
% print results
for var_index = 1:length(output_var_array);
    var = output_var_array{var_index};
    
    filename=['../output/', dataset, '_priority/',var,'_priority_summary.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%d, ',num{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_aboveJND.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%d, ',num_aboveJND{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_aboveJNDRatio.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%.5f, ',num_aboveJND{var_index, alpha_index}/num{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_minPE.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%.6f, ',minPE{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_minPE_debiased.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%.6f, ',minPE_debiased{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_subgraphQ.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%.6f, ',subgraphQ{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_group_size.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%s, ',mat2str((group_size{var_index, alpha_index})'));
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_delta_theta.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%s, ',mat2str((delta_theta{var_index, alpha_index})'));
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
    filename=['../output/', dataset, '_priority/',var,'_priority_visibility.csv'];
    fid = fopen(filename,'at');
    fprintf(fid,'%50s (%.2f  %.2f), ', method, JND, theta);
    for alpha_index = 1:length(alpha_array);
        fprintf(fid,'%.6f, ',visibility{var_index, alpha_index});
    end;
    fprintf(fid,'\n');
    fclose(fid);
    
end;