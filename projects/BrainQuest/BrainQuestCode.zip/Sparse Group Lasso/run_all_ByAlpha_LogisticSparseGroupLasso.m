
clear;

warning('off','stats:LinearModel:RankDefDesignMat');
warning('off','stats:glmfit:PerfectSeparation');

addpath(genpath(['./lib/SLEP']));
addpath(genpath(['./lib/MIT']));
poolobj = gcp;
addAttachedFiles(poolobj,{'./iterate_ByAlpha_LogisticSparseGroupLasso.m'});
addAttachedFiles(poolobj,{'./lib/MIT/newman_comm_fast_single_thread.m'});

% dataset = 'brain_logistic';
% dataset_array = {'brain_logistic_small','brain_logistic_medium','brain_logistic_full'};
% dataset_array = {'brain_logistic_medium','brain_logistic_full'};
dataset_array = {'brain_logistic_full'};

% trial_array, aligning method, clustering_type, JND value and theta value
trial_num = 19;
trial_array = linspace(1,trial_num,trial_num);

% clustering_type: 1: use node_clustering by strength data; 2: use
% node_clustering by JNI data; 3: use edge_clustering by JNI_minus data;4:
% use edge_clustering by JNI_multi data;
%
% 11: single cluster, group lasso; 
% 21: JND value based biclustering, above JND, below JND
clustering_type_array = {1,2,3,4,5,6,7,8,11,21,21,21,21,21,21,21,21,21,21};
% clustering_type_array = {1,2,3,4,5,6,7,8,11,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21};
% clustering_type_array = {1,2,3,4,11,21,21,21,21,21};

% method for clustering, etc.
method_by_clustering_type = cell(1,30);
method_by_clustering_type{1} = 'strength_node_graph_clustering';
method_by_clustering_type{2} = 'JNI_node_graph_clustering';
method_by_clustering_type{3} = 'strength_minus_line_graph_clustering';
method_by_clustering_type{4} = 'strength_multi_line_graph_clustering';
method_by_clustering_type{5} = 'JNI_minus_line_graph_clustering';
method_by_clustering_type{6} = 'JNI_multi_line_graph_clustering';
method_by_clustering_type{7} = 'delta_JNI_minus_line_graph_clustering';
method_by_clustering_type{8} = 'delta_JNI_multi_line_graph_clustering';
method_by_clustering_type{11} = 'Single_group';
% method_by_clustering_type{21} = 'Two_group_by_JNI_threshold';
method_by_clustering_type{21} = 'Two_group_by_p_value_threshold';

JND_array={1,1,1,1,1,1,1,1,1,0.05,0.1,0.2,0.5,1,0.05,0.1,0.2,0.5,1};
theta_array={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0.5,0.5,0.5,0.5};
% JND_array={1,1,1,1,1,1,1,0.05,0.1,0.2,0.5,1,0.05,0.1,0.2,0.5,1,0.05,0.1,0.2,0.5,1};
% theta_array={0,0,0,0,0,0,0,0,0,0,0,0,0.2,0.2,0.2,0.2,0.2,0.5,0.5,0.5,0.5,0.5};
% theta_array={0,0,0,0,0,0,0,0,0,0};
% JND_array={1,1,1,1,1,0.05,0.1,0.2,0.5,1};

if ~(length(trial_array)==length(clustering_type_array));
    Error('clustering_type_array size not accord!');
end;    

if ~(length(trial_array)==length(JND_array));
    Error('JND_array size not accord!');
end;    

if ~(length(trial_array)==length(theta_array));
    Error('theta_array size not accord!');
end;

%output_var_array = {'age','CCI','FSIQ','Agree','Consci','Extra','Neu','Open'};
output_var_array = {'CCI_Class'};
alpha_array={0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1};

for dataset_index = 1:length(dataset_array);
    
    dataset = dataset_array{dataset_index};
    
    for trial_index = 1:length(trial_array);
        
        clustering_type = clustering_type_array{trial_index};
        JND = JND_array{trial_index};
        theta = theta_array{trial_index};
        
        method = method_by_clustering_type{clustering_type};
        
        disp(['Computing with ', method, ' on ', dataset,' for JND=',num2str(JND),', theta=',num2str(theta)]);
        iterate_ByAlpha_LogisticSparseGroupLasso(method, dataset, clustering_type, JND, theta, output_var_array, alpha_array)
        
        disp(['Transforming to txt for JND=',num2str(JND),', theta=',num2str(theta)]);
        save_ByAlpha_LogisticSparseGroupLasso(method, dataset, JND, theta, output_var_array, alpha_array);
    end;
end;

