
function delta_theta = priorityOptimization(B_c, Intercept_c, feature_index_group, visible_ratio_threshold, edge_clustering_visible_ratio, alpha, lambda,current_edge_feature, outcome)

stepsize = abs(mean(B_c));
min_stepsize = 0.01 * abs(mean(B_c));
min_error = 0.0001;
max_loop = 1000;

X = current_edge_feature;
Y = outcome;

M = length(feature_index_group);
w = B_c;
w_0 = Intercept_c;
w_group = cell(1,M);
p = cellfun(@length,feature_index_group);
group = feature_index_group;
xi = visible_ratio_threshold;
xi_group = cell2mat(edge_clustering_visible_ratio);
delta_theta = zeros(1,M);
gamma = zeros(1,M);
delta_gamma = zeros(1,M);
cost = zeros(1,M);
invest = zeros(1,M);
w_group_norm = zeros(1,M);
soft_threshold_norm = zeros(1,M);

budget = 0;
F_set = [];

exp_YWTX = exp((-Y).*(X * w));

for m = 1:M;
    
    w_group{m} = w(group{m});
    
    if length(find(w_group{m})) > 0;
        gamma(m) = 1;
    end;
    
    % set L2 norm of w_group{m}
    w_group_norm(m) = norm(w_group{m});
    if w_group_norm(m) == 0;
        w_group_m_new = zeros(1,length(group{m}));
        
        % compute the updated w_j
        
        for index = 1:length(w_group_m_new);
            right_side = -lambda * (alpha + (1-alpha) * sqrt(p(m)));
            j = group{m}(index);
            w_j = 0;        
            YXj = Y.*X(:,j);
            Differential_0 = sum((exp_YWTX.*(-YXj))./(1+exp_YWTX));
            if abs(Differential_0) <= abs(right_side); 
                continue;
            end;
                        
            cur_stepsize = abs(stepsize) * (-sign(Differential_0));
            right_side = right_side * sign(cur_stepsize) + sum(YXj);
            loop = 0;
            while (cur_stepsize >= min_stepsize) && (loop < max_loop);
                
                exp_yXWj = exp(-YXj*w_j);
                left_side = sum(YXj./(1+exp_YWTX.*exp_yXWj));
                error = left_side - right_side;
                
                w_j_new = w_j + cur_stepsize;
                
                exp_yXWj = exp(-YXj*w_j_new);
                left_side_new = sum(YXj./(1+exp_YWTX.*exp_yXWj));
                error_new = left_side_new - right_side;
                
                if(abs(error_new) < min_error);
                    w_j = w_j_new;
                    break;
                end;
                
                if error * error_new > 0;
                    w_j = w_j_new;
                else;
                    cur_stepsize = cur_stepsize/2;
                end;
                
                loop = loop + 1;
            end;
            
            w_group_m_new(index) = w_j;
            %disp(['Compute updated w_',num2str(j),'=',num2str(w_j),' in ',num2str(loop),' steps!']);
        end;   
        
        w_group_norm(m) = norm(w_group_m_new);
    end;
    
    % compute soft thresholding
    soft_threshold = zeros(1,length(group{m}));
    for index = 1:length(group{m});
            j = group{m}(index);
            YXj = Y.*X(:,j);
            Differential = sum((exp_YWTX.*(-YXj))./(1+exp_YWTX));
            soft_threshold(index) = max(0, abs(Differential)-alpha*lambda);
    end;    
    soft_threshold_norm(m) = norm(soft_threshold);
    
    cost(m) = w_group_norm(m) * abs(soft_threshold_norm(m)/((1-alpha)*lambda) - sqrt(p(m))) ;    
    invest(m) = p(m) * (xi_group(m) - xi);
    budget = budget + p(m) * gamma(m) * (xi - xi_group(m));
    
    if (gamma(m) - 0.5) * invest(m) < 0;
        F_set = union(F_set, [m]);
    end;
            
end;

efficiency = zeros(1,M);
while budget > 0 && length(F_set) > 0;
    for index = 1:length(F_set);
        m = F_set(index);
        efficiency(m) = min(budget,abs(invest(m)))/cost(m);
    end;
    
    % sort F_set by efficiency
    [~,order]=sort(efficiency(F_set),'descend');
    F_set=F_set(order);

    selected = F_set(1);
    delta_gamma(selected) = 1 - gamma(selected);
    delta_theta(selected) = soft_threshold_norm(selected)/((1-alpha)*lambda*sqrt(p(selected))) - 1;
    
    if delta_gamma(selected) * delta_theta(selected) > 0;
        warning(['Something must be wrong in group ', num2str(selected), ': priority optimization direction falsely reversed, disable the optimization!']);
        delta_theta(selected) = 0;
    end;
    
    budget = budget - abs(invest(selected));
    F_set = setdiff(F_set, [selected],'stable');
    
end;











