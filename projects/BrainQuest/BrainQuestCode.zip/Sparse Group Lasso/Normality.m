clear;

dataset = 'brain_logistic_full.mat';
eval(['load ../data/', dataset]);

p_normality = zeros(2,2415);

for i = 1:2415;
    [h,p_normality(1,i)] = kstest(edge_feature(find(CCI_Class==1),i));
    [h,p_normality(2,i)] = kstest(edge_feature(find(CCI_Class==-1),i));
end;    

clear dataset;
eval(['save ../data/', dataset]);