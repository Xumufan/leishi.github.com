clear;

dataset = 'brain_logistic_medium.mat';
eval(['load ../data/', dataset]);

addpath(genpath(['./lib/MIT']));
poolobj = gcp;
addAttachedFiles(poolobj,{'./lib/MIT/newman_comm_fast.m'});

% define min threshold for edge features to use for clustering
value_threshold = 10;

% truncate edge features smaller than threshold
avg_edge_feature = mean(edge_feature, 1);
selected_feature_index = find(avg_edge_feature>=value_threshold);

% create adjacency matrix
brainAdj = zeros(nodeCount, nodeCount);

% fill adjacency matrix by selected features from brain data
for i = 1:size(selected_feature_index,2);
    selected_index = selected_feature_index(1,i);
    src_index = srcIndexMap(selected_index,1);
    dst_index = dstIndexMap(selected_index,1);
%     brainAdj(src_index, dst_index) = avg_edge_feature(1, selected_index);
%     brainAdj(dst_index, src_index) = avg_edge_feature(1, selected_index);
    brainAdj(src_index, dst_index) = CCI_Ratio(1, selected_index);
    brainAdj(dst_index, src_index) = CCI_Ratio(1, selected_index);
end;

[groups_hist,Q]=newman_comm_fast(brainAdj);

[maxQ, maxQ_index] = max(Q);
% maxQ_index = 64;
node_clustering = groups_hist{maxQ_index};

% single node clustering
% node_clustering = cell(1);
% node_clustering{1} = round(linspace(1,nodeCount,nodeCount));

nodeClusterIndexMap = zeros(1, nodeCount);
for i = 1:length(node_clustering);
    cluster = node_clustering{i};
    for j = 1: size(cluster,2);
        nodeClusterIndexMap(1, cluster(1,j)) = i;
    end;
end;

edgeClusterIndexMap = zeros(1, size(edge_feature,2));
edgeClusterIndexMap(:) = length(node_clustering) + 1;
for i = 1:size(edge_feature,2);
    srcIndex = srcIndexMap(i,1);
    dstIndex = dstIndexMap(i,1);
    srcClusterIndex = nodeClusterIndexMap(1,srcIndex);
    dstClusterIndex = nodeClusterIndexMap(1,dstIndex);
    
    if srcClusterIndex == dstClusterIndex;
        edgeClusterIndexMap(1,i) = srcClusterIndex;    
    end;
end;

edge_clustering_by_JNI = cell(1,length(node_clustering)+1);

for i = 1:(length(node_clustering) + 1);
    edge_clustering_by_JNI{i} = find(edgeClusterIndexMap == i);
end;
clear value_threshold avg_edge_feature selected_feature_index selected_index src_index dst_index;
clear maxQ maxQ_index cluster node_clustering
clear i j nodeClusterIndexMap group srcIndex dstIndex srcClusterIndex dstClusterIndex
eval(['save ../data/', dataset]);




% define min threshold for edge features to use for clustering
value_threshold = 10;

% truncate edge features smaller than threshold
avg_edge_feature = mean(edge_feature, 1);
selected_feature_index = find(avg_edge_feature>=value_threshold);

% create adjacency matrix
brainAdj = zeros(nodeCount, nodeCount);

% fill adjacency matrix by selected features from brain data
for i = 1:size(selected_feature_index,2);
    selected_index = selected_feature_index(1,i);
    src_index = srcIndexMap(selected_index,1);
    dst_index = dstIndexMap(selected_index,1);
    brainAdj(src_index, dst_index) = avg_edge_feature(1, selected_index);
    brainAdj(dst_index, src_index) = avg_edge_feature(1, selected_index);
%     brainAdj(src_index, dst_index) = CCI_Ratio(1, selected_index);
%     brainAdj(dst_index, src_index) = CCI_Ratio(1, selected_index);
end;

[groups_hist,Q]=newman_comm_fast(brainAdj);

[maxQ, maxQ_index] = max(Q);
% maxQ_index = 64;
node_clustering = groups_hist{maxQ_index};

% single node clustering
% node_clustering = cell(1);
% node_clustering{1} = round(linspace(1,nodeCount,nodeCount));

nodeClusterIndexMap = zeros(1, nodeCount);
for i = 1:length(node_clustering);
    cluster = node_clustering{i};
    for j = 1: size(cluster,2);
        nodeClusterIndexMap(1, cluster(1,j)) = i;
    end;
end;

edgeClusterIndexMap = zeros(1, size(edge_feature,2));
edgeClusterIndexMap(:) = length(node_clustering) + 1;
for i = 1:size(edge_feature,2);
    srcIndex = srcIndexMap(i,1);
    dstIndex = dstIndexMap(i,1);
    srcClusterIndex = nodeClusterIndexMap(1,srcIndex);
    dstClusterIndex = nodeClusterIndexMap(1,dstIndex);
    
    if srcClusterIndex == dstClusterIndex;
        edgeClusterIndexMap(1,i) = srcClusterIndex;    
    end;
end;

edge_clustering_by_strength = cell(1,length(node_clustering)+1);

for i = 1:(length(node_clustering) + 1);
    edge_clustering_by_strength{i} = find(edgeClusterIndexMap == i);
end;
clear value_threshold avg_edge_feature selected_feature_index selected_index src_index dst_index;
clear maxQ maxQ_index cluster node_clustering
clear i j nodeClusterIndexMap group srcIndex dstIndex srcClusterIndex dstClusterIndex
eval(['save ../data/', dataset]);
