
function iterate_ByAlpha_LogisticSparseGroupLasso(method, dataset, clustering_type, visible_JND, group_scale_theta, output_var_array, alpha_array)

% prepare environmental setting
% clear;

% disp(flag_writeable);
addpath(genpath(['./lib/SLEP']));
addpath(genpath(['./lib/MIT']));

eval(['load ../data/',dataset]);

visibility_threshold = 0.11 * 0.3;

% input parameters
lambda_grid_size = 100;
lambda_value_size = 20;

% fold_size = 1;
% fold_size = 10;
fold_size = 12;

data_size = size(edge_feature,1);   
cross_validation_fold = ceil(data_size / fold_size);

% use parallel computing
% matlab_opt = statset('UseParallel',true);

% define min threshold for edge features to use, truncate all features with
% average value lower than that
value_threshold = 10;
log_value_threshold = 0;

% feature engineering
raw_edge_feature = edge_feature;
current_edge_feature = raw_edge_feature;

% truncate edge features smaller than threshold
avg_edge_feature = mean(current_edge_feature);
% std_ratio_edge_feature = std(current_edge_feature, 1)./avg_edge_feature;
% nontrivial_feature_index = intersect(find(avg_edge_feature>=value_threshold), find(std_ratio_edge_feature>=1e-10));
nontrivial_feature_index = find(avg_edge_feature>=value_threshold);
nontrivial_edge_feature = current_edge_feature(:, nontrivial_feature_index);

current_edge_feature = nontrivial_edge_feature;
current_edge_index = nontrivial_feature_index;
current_CCI_Ratio = CCI_Ratio(:, nontrivial_feature_index);
current_p_CCI_Class = p_CCI_Class(:, nontrivial_feature_index);

% create log value for the input feature, truncate edge features smaller than threshold 
nontrivial_edge_feature_log = log10(current_edge_feature);
nontrivial_edge_feature_log(nontrivial_edge_feature_log <= log_value_threshold) = log_value_threshold;

current_edge_feature = nontrivial_edge_feature_log;

% find visible group in input feature vector
% visible_nontrivial_feature_index = find(current_CCI_Ratio>=visible_JND);
% invisible_nontrivial_feature_index = find(current_CCI_Ratio<visible_JND);

visible_nontrivial_feature_index = find(current_p_CCI_Class<=visible_JND);
invisible_nontrivial_feature_index = find(current_p_CCI_Class>visible_JND);


if not(isempty(intersect(visible_nontrivial_feature_index, invisible_nontrivial_feature_index)));
    disp('Error: has overlapping groups!');
    return;
end;

% create group index {M_i}, M_i is a 1 x n_i matrix identifying the index
% of group i (n_i indices)

if clustering_type <= 10;
    % create feature group by edge clustering
    % remove edge features not selected from edge_clustering    
    
    edge_clustering = '';
    
    if clustering_type == 1;
        edge_clustering = edge_clustering_by_strength;
    elseif clustering_type == 2;
        edge_clustering = edge_clustering_by_JNI;
    elseif clustering_type == 3;
        edge_clustering = edge_clustering_by_line_strength_minus;
    elseif clustering_type == 4;
        edge_clustering = edge_clustering_by_line_strength_multi;
    elseif clustering_type == 5;
        edge_clustering = edge_clustering_by_line_JNI_minus;
    elseif clustering_type == 6;
        edge_clustering = edge_clustering_by_line_JNI_multi;
    elseif clustering_type == 7;
        edge_clustering = edge_clustering_by_line_delta_JNI_minus;
    elseif clustering_type == 8;
        edge_clustering = edge_clustering_by_line_delta_JNI_multi;
    else;
        Error(['Not a legal clustering type: ',num2str(clustering_type)]);
    end;
    
    feature_group_weight = zeros(1,length(edge_clustering));
    feature_index_group = cell(1,length(edge_clustering));
    for c = 1:length(edge_clustering);
        [inter_value, ia, ib] = intersect(edge_clustering{c}, current_edge_index);
        feature_index_group{c} = ib;
        feature_group_weight(1,c) = sqrt(length(feature_index_group{c}));
    end;
elseif clustering_type == 11;
    % use the single group
    feature_index_group{1} = linspace(1,size(current_edge_index,2), size(current_edge_index,2));
    feature_group_weight(1,1) = sqrt(length(feature_index_group{1}));
elseif clustering_type == 21;
    % use visible classification as grouping
    feature_index_group{1} = visible_nontrivial_feature_index;
    feature_index_group{2} = invisible_nontrivial_feature_index;
    feature_group_weight(1,1) = sqrt(length(feature_index_group{1}))* (1-group_scale_theta);
    feature_group_weight(1,2) = sqrt(length(feature_index_group{2}));    
else;
    Error(['Not a legal clustering type: ',num2str(clustering_type)]);
end;

feature_group_weight(feature_group_weight <= 0) = 1;

if clustering_type<=20;
    visible_JND = 1;
    group_scale_theta = 0;
end;
    
% reorder the feature matrix to continous groups across column
group_edge_feature = zeros(size(current_edge_feature));
group_edge_index = zeros(size(current_edge_index));

start_index = 1;
for l = 1:length(feature_index_group);
    index_length = length(feature_index_group{l});
    group_edge_feature(:,start_index:(start_index+index_length-1)) = current_edge_feature(:,feature_index_group{l});
    group_edge_index(:,start_index:(start_index+index_length-1)) = current_edge_index(:,feature_index_group{l});
    feature_index_group{l} = [start_index:(start_index+index_length-1)];
    start_index = start_index + index_length;    
end;

current_edge_feature = group_edge_feature;
current_edge_index = group_edge_index;

% normalization columnwise
% the current feature matrix A is normalized to
% A= ( A- repmat(mu, m,1) ) * diag(nu)^{-1}
% mu is the mean vector of A;
% nu is the std vector after A = A - repmat(mu, m,1);

mu = sum(current_edge_feature,1)./size(current_edge_feature,1);
current_edge_feature = current_edge_feature- repmat(mu, size(current_edge_feature,1),1);

nu = sqrt(sum(current_edge_feature.^2,1)./size(current_edge_feature,1));
current_edge_feature = current_edge_feature * diag(nu)^(-1);

%----------------------- SLEP sparse group lasso setup -----------------------
opts=[];

% Starting point
opts.init=2;        % starting from a zero point

% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=1000;   % maximum number of iterations

% regularization
opts.rFlag=0;       % use ratio

% Normalization
opts.nFlag= 0;       % do not normalize because we have done this;
%opts.nFlag= 1;       % use columnwise normalization to zero expectation and one variance (? to be examined)

% Group Property
%opts.ind=[ [1, 20, sqrt(20)]', [21, 40, sqrt(20)]',...
%    [41, 50, sqrt(10)]', [51, 70, sqrt(20)]', [71,100, sqrt(30)]'];

opts.ind = zeros(3,length(feature_index_group));

start_index = 1;
for l = 1:length(feature_index_group);    
    index_length = length(feature_index_group{l});
    opts.ind(:,l)=[start_index, start_index + index_length-1, feature_group_weight(1,l)]';
    start_index = start_index + index_length;
end;

if ( min(opts.ind(3,:))<=0 );
    error('\n In this case, lambda2_max = inf!');    
end;
        
sample_weight=ones(size(current_edge_feature,1),1)/size(current_edge_feature,1);

%----------------------- Run the code -----------------------

for k = 1:length(output_var_array);
    output_var = output_var_array{k};       
    eval(['outcome=',output_var,';']);
    
    %
    % generate cross-validation data sets
    % use fixed randomness, full saturation - even out data partition
    %  
    linseq_data_index = linspace(1, data_size, data_size);
    cross_validate_prediction_feature_set = cell(1,cross_validation_fold);
    cross_validate_test_feature_set = cell(1,cross_validation_fold);
    cross_validate_prediction_outcome_set = cell(1,cross_validation_fold);
    cross_validate_test_outcome_set = cell(1,cross_validation_fold);
%     cross_validate_prediction_feature_set_org = cell(1,cross_validation_fold);
%     cross_validate_test_feature_set_org = cell(1,cross_validation_fold);
    
    parfor i = 1:cross_validation_fold;
        
        start_index = 1 + (i - 1) * fold_size;
        if (i==cross_validation_fold);
            end_index = data_size;
        else;
            end_index = start_index + fold_size - 1;
        end;
        
        current_fold_index = linseq_data_index(1,start_index:end_index);
        current_validate_test_feature=current_edge_feature(current_fold_index,:);
        current_validate_test_outcome=outcome(current_fold_index,:);
        
        current_fold_index = linseq_data_index(1,[1:start_index-1 end_index+1:data_size]);
        current_validate_prediction_feature=current_edge_feature(current_fold_index,:);
        current_validate_prediction_outcome=outcome(current_fold_index,:);
        
%         cross_validate_test_feature_set_org{1,i}=current_validate_test_feature;
%         cross_validate_prediction_feature_set_org{1,i}=current_validate_prediction_feature;
        
        % normalization on feature sets
        mu_cross = sum(current_validate_test_feature,1)./size(current_validate_test_feature,1);
        current_validate_test_feature = current_validate_test_feature - repmat(mu_cross, size(current_validate_test_feature,1),1);
        
        nu_cross = sqrt(sum(current_validate_test_feature.^2,1)./size(current_validate_test_feature,1));
        nu_cross(nu_cross<=1e-10) = 1;
        current_validate_test_feature = current_validate_test_feature * diag(nu_cross)^(-1);
        
        mu_cross = sum(current_validate_prediction_feature,1)./size(current_validate_prediction_feature,1);
        current_validate_prediction_feature = current_validate_prediction_feature - repmat(mu_cross, size(current_validate_prediction_feature,1),1);
        
        nu_cross = sqrt(sum(current_validate_prediction_feature.^2,1)./size(current_validate_prediction_feature,1));
        nu_cross(nu_cross<=1e-10) = 1;
        current_validate_prediction_feature = current_validate_prediction_feature * diag(nu_cross)^(-1);
        
        cross_validate_test_feature_set{1,i}=current_validate_test_feature;
        cross_validate_test_outcome_set{1,i}=current_validate_test_outcome;
        
        cross_validate_prediction_feature_set{1,i}=current_validate_prediction_feature;
        cross_validate_prediction_outcome_set{1,i}=current_validate_prediction_outcome;              
        
    end;
    
    rng('shuffle');
    
    % compute the feasible contour of lambda_1, lambda_2
    
    % compute lambda1_max
    
    p_flag=(outcome==1);                  % the indices of the postive samples
    m1=sum(sample_weight(p_flag));         % the total weight for the positive samples
    m2=1-m1;                        % the total weight for the positive samples
    
    b(p_flag,1)=m2;  b(~p_flag,1)=-m1;
    b=b.*sample_weight;
    
    ATb_abs =abs(current_edge_feature'*b);
    lambda1_max=max(ATb_abs);
    
    lambda1_grid_array = linspace(0,1,lambda_grid_size+1);
    lambda1_grid_array = lambda1_grid_array.*lambda1_max;   
    
    lambda2_max_array = zeros(1,lambda_grid_size+1);        
    
    % compute lambda2_max(lambda_1)       
    for i = 1:lambda_grid_size+1;
        lambda1 = lambda1_grid_array(1,i);
        
        % compute lambda2_max(lambda_1)
        temp=max(ATb_abs-lambda1,0);                       
        lambda2_max=computeLambda2Max(temp,size(current_edge_feature, 2),opts.ind,size(opts.ind,2));
        lambda2_max_array(1,i)=lambda2_max;
    end;          
    
%     plot (lambda1,lambda2) feasiblity range
%     figure;
%     plot(lambda1_grid_array, lambda2_max_array);
%     axis([0,5,0,5])    
    
    Nonzeros = strcat('Nonzeros_', output_var);
    eval([Nonzeros,'=zeros(',num2str(length(alpha_array)),',',num2str(lambda_value_size),');']);
    
    FunVals = strcat('FunVals_', output_var);
    eval([FunVals,'=zeros(',num2str(length(alpha_array)),',',num2str(lambda_value_size),');']);
    
    tic;
    
    for i = 1:length(alpha_array);  
        alpha = alpha_array{i};
        alpha_string = num2str(alpha * 100);                    
            
        % compute lambda_max;        
        lambda_max = 0;
        
        if (alpha<0 || alpha > 1);
            disp(['Invalid alpha value ', num2str(alpha)]);
            return;
        elseif alpha == 0;
            lambda_max = lambda2_max_array(1,1);
        elseif alpha == 1;
            lambda_max = lambda1_max;
        else;
            alpha_slope = (1-alpha)/alpha;
            alpha_line_array = lambda1_grid_array * alpha_slope;
            
            error_vector = alpha_line_array - lambda2_max_array;
            [min_index_i, min_index_j] = find(error_vector>=0, 1);
            lambda_max = alpha_line_array(1,min_index_j) + lambda1_grid_array(1,min_index_j);           
        end;
        
        % compute lambda_array        
        lambda_array = logspace(log10(lambda_max * 1.5), log10(lambda_max * 0.015), lambda_value_size);
                       
        B_var=zeros(size(current_edge_feature, 2),lambda_value_size);
        
        % Deviance = mean prediction error
        % SE = standard error (deviation) of cross-validated prediction error
        % 1SE = Deviance + 1 * SE
        % Index1SE = the index of the largest lambda with PE <= 1SE        
        FitInfo_var = struct('Intercept',zeros(1,lambda_value_size),'Lambda',lambda_array,'Alpha',alpha,'DF',zeros(1,lambda_value_size),'Deviance',zeros(1,lambda_value_size),'SE',zeros(1,lambda_value_size),'LambdaMinDeviance',lambda_array(1,1),'IndexMinDeviance',1,'Lambda1SE',lambda_array(1,1),'Index1SE',1, 'NLL',zeros(1,lambda_value_size),'IndexMinNLL',1,'Deviance_debiased',zeros(1,lambda_value_size),'SE_debiased',zeros(1,lambda_value_size),'LambdaMinDeviance_debiased',lambda_array(1,1),'IndexMinDeviance_debiased',1, 'NLL_debiased',zeros(1,lambda_value_size),'IndexMinNLL_debiased',1,'subgraphQ',zeros(1,lambda_value_size),'Group_Size',zeros(length(feature_index_group),lambda_value_size),'visibility',zeros(1,lambda_value_size));        
        
        for j = 1:length(lambda_array);
            
            lambda = lambda_array(1,j);
            
            lambda_1 = lambda * alpha;            
            lambda_2 = lambda * (1-alpha);
            
            lambda_vector = [lambda_1, lambda_2];
            
            [B_c, Intercept_c, FunVal_c, L_c] = sgLogisticR(current_edge_feature,outcome,lambda_vector,opts);            
            
            B_var(:,j)=B_c;
                        
            DF = sum(B_c~=0);            
            FitInfo_var.Intercept(1,j) = Intercept_c;
            FitInfo_var.DF(1,j) = DF;
            eval([Nonzeros,'(',num2str(i),',',num2str(j),')=DF;']);
            eval([FunVals,'(',num2str(i),',',num2str(j),')=min(FunVal_c);']);    
            
            % compute selected feature size in each group
            selected_current_feature_index = find(B_c~=0);
                        
            for group_index = 1: length(feature_index_group);
                FitInfo_var.Group_Size(group_index,j) = length(intersect(feature_index_group{group_index}, selected_current_feature_index));                
            end;                       
            
            % create adjacency matrix
            subgraphAdj = zeros(nodeCount, nodeCount);
            selected_feature_index = current_edge_index(find(B_c~=0));
            % fill adjacency matrix by selected features from brain data
            for adj_index = 1:size(selected_feature_index,2);
                selected_index = selected_feature_index(1,adj_index);
                edge_value = avg_edge_feature(1, selected_index);
                src_index = srcIndexMap(selected_index,1);
                dst_index = dstIndexMap(selected_index,1);                
                subgraphAdj(src_index, dst_index) = edge_value;
                subgraphAdj(dst_index, src_index) = edge_value;
            end;
            
            % compute best modularity
            [~,Q]=newman_comm_fast_single_thread(subgraphAdj);   
            [FitInfo_var.subgraphQ(1,j), ~] = max(Q);    
            
            % compute visiblity ratio
            FitInfo_var.visibility(1,j) = sum(min(CCI_Class_Diff_Ratio(selected_feature_index)/visibility_threshold, 1))/length(selected_feature_index);
            
            % use the average residual as the prediction error
            % PE = mean((residual-Intercept).^2);                       
            % FitInfo_var.PE(1,j) = PE;
            
            % use cross-validation by #cross_validation_fold fold as the prediction error
            PE = zeros(1,cross_validation_fold);
            NLL = zeros(1,cross_validation_fold);
            
            PE_debiased = zeros(1,cross_validation_fold);
            NLL_debiased = zeros(1,cross_validation_fold);
            
%             B_cross_array = cell(1,cross_validation_fold);
%             Intercept_cross_array = cell(1,cross_validation_fold);
%             FunVal_cross_array = cell(1,cross_validation_fold);
%             L_cross_array = cell(1,cross_validation_fold);            
            
%             for f = 1:cross_validation_fold;
%                 % run each fold prediction
%                 prediction_feature = cross_validate_prediction_feature_set{1,f};
%                 prediction_outcome = cross_validate_prediction_outcome_set{1,f};
%                 
%                 [B_cross_array{1,f},Intercept_cross_array{1,f},FunVal_cross_array{1,f},L_cross_array{1,f}] = sgLogisticR(prediction_feature,prediction_outcome,lambda_vector,opts);
%             end;
            
            parfor f = 1:cross_validation_fold;
                
                prediction_feature = cross_validate_prediction_feature_set{1,f};
                prediction_outcome = cross_validate_prediction_outcome_set{1,f};
                test_feature = cross_validate_test_feature_set{1,f};
                test_outcome = cross_validate_test_outcome_set{1,f};
                
%                 B_cross = B_cross_array{1,f};
%                 Intercept_cross = Intercept_cross_array{1,f};
%                 FunVal_cross = FunVal_cross_array{1,f};
%                 L_cross = L_cross_array{1,f};
                
                  % test the PE, SE of result
                
%                 NLL_cross = sum(-log((1 + exp(-test_outcome.*(test_feature*B_cross+Intercept_cross))).^(-1)));
%                 NLL(1,f) = NLL_cross;
                
%                 Prediction = test_feature*B_cross+Intercept_cross;
%                 Prediction(Prediction>=0) = 1;
%                 Prediction(Prediction<0) = -1;                
%                 PE_cross = size(find((Prediction + test_outcome)==0),1)/size(test_outcome,1);                
%                 PE(1,f) = PE_cross;          
                
                % obtain the debiased estimation and cross-validation errors
                % use cross-validation by #cross_validation_fold fold as the prediction error
                % use the org (un-normalized) prediction/test feature for logistic regression         
                
%                 prediction_feature = cross_validate_prediction_feature_set_org{1,f};
%                 test_feature = cross_validate_test_feature_set_org{1,f};
                
                predictors = find(B_c~=0);                                
%                 predictors = find(B_cross~=0);
                prediction_outcome(find(prediction_outcome==-1)) = 0;
                
                if ~isempty(predictors);
                    warning('off','stats:LinearModel:RankDefDesignMat');
                    warning('off','stats:glmfit:PerfectSeparation');
                    mdl = fitglm(prediction_feature,prediction_outcome,'linear','Distribution','binomial','PredictorVars',predictors);
                    B_debiased = mdl.Coefficients(:,1);
                    B_debiased = table2array(B_debiased);
                    Intercept_debiased = B_debiased(1,1);
                    B_debiased = B_debiased(2:size(B_debiased,1), 1);
                else;
                    Intercept_debiased = mean(prediction_outcome);
                    B_debiased = zeros(size(predictors,1),1);
                end;
                
                % test the PE, SE of result with the debiased model
                test_feature_debiased = test_feature(:, predictors);
                test_outcome(find(test_outcome==-1)) = 0;
                                
                prob = (1 + exp(-test_feature_debiased*B_debiased-Intercept_debiased)).^(-1);
                NLL_debiased(1,f) = -sum(log(prob).*test_outcome + log(1-prob).*(1-test_outcome));
                
                if isempty(predictors);
                    Prediction = zeros(size(test_outcome)) + Intercept_debiased(1,1);
                else;
                    Prediction = test_feature_debiased*B_debiased+Intercept_debiased(1,1);
                end;
                
                Prediction(Prediction>=0) = 1;
                Prediction(Prediction<0) = 0;
                PE_debiased_cross = size(find((Prediction + test_outcome)==1),1)/size(test_outcome,1);
                
                PE_debiased(1,f) = PE_debiased_cross;
                
                % test the debiased model on the prediction data set
%                 prediction_feature_debiased = prediction_feature(:, predictors);
%                                 
%                 prob = (1 + exp(-prediction_feature_debiased*B_debiased-Intercept_debiased)).^(-1);
%                 
%                 if isempty(predictors);
%                     Prediction = zeros(size(prediction_outcome)) + Intercept_debiased(1,1);
%                 else;
%                     Prediction = prediction_feature_debiased*B_debiased+Intercept_debiased(1,1);
%                 end;
%                 
%                 Prediction(Prediction>=0) = 1;
%                 Prediction(Prediction<0) = 0;
%                 PE_debiased_cross = size(find((Prediction + prediction_outcome)==1),1)/size(prediction_outcome,1);
%                 disp(['Debiased PE:' PE_debiased_cross]);
            end;
            
            FitInfo_var.Deviance(1,j) = mean(PE);
            FitInfo_var.SE(1,j) = std(PE,1);              
            FitInfo_var.NLL(1,j) = mean(NLL);          
            
            FitInfo_var.Deviance_debiased(1,j) = mean(PE_debiased);
            FitInfo_var.SE_debiased(1,j) = std(PE_debiased,1);              
            FitInfo_var.NLL_debiased(1,j) = mean(NLL_debiased);                                                 
                                
            disp(['Modeling ' output_var ' on lambda_1=' num2str(lambda_1) ', lambda_2=' num2str(lambda_2) ' finished (sparse group lasso), JND=', num2str(visible_JND),', theta=', num2str(group_scale_theta), '!']);
            
        end;
        
        [minPE, FitInfo_var.IndexMinDeviance] = min(FitInfo_var.Deviance);
        FitInfo_var.LambdaMinDeviance = lambda_array(1,FitInfo_var.IndexMinDeviance);
        
        [minNLL, FitInfo_var.IndexMinNLL] = min(FitInfo_var.NLL);
        
        minSE = FitInfo_var.SE(1,FitInfo_var.IndexMinDeviance);
        OneSE = minPE + minSE;
        FitInfo_var.Index1SE = find(FitInfo_var.Deviance<=OneSE, 1);        
        FitInfo_var.Lambda1SE = lambda_array(1,FitInfo_var.Index1SE);
        
        [minPE_debiased, FitInfo_var.IndexMinDeviance_debiased] = min(FitInfo_var.Deviance_debiased);
        FitInfo_var.LambdaMinDeviance_debiased = lambda_array(1,FitInfo_var.IndexMinDeviance_debiased);
        
        [minNLL_debiased, FitInfo_var.IndexMinNLL_debiased] = min(FitInfo_var.NLL_debiased);
        
        B = strcat('B_', output_var, '_', alpha_string);
        FitInfo = strcat('FitInfo_', output_var, '_', alpha_string);
        eval([FitInfo,'=FitInfo_var;']);
        eval([B,'=B_var;']);
    end;
    
    toc;
    
end;

dirName = ['../output/', dataset, '/raw'];
if exist(dirName, 'dir') == 0;
    mkdir(dirName);
end;

%clear cross_validate_prediction_feature_set cross_validate_test_feature_set cross_validate_prediction_outcome_set cross_validate_test_outcome_set B_cross_array;
    
eval(['save(''../output/', dataset, '/raw/',method,'_SGL_JND=',num2str(visible_JND*100),'_Theta=',num2str(group_scale_theta*100),'.mat'');']);


