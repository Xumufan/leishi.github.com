clear;

dataset = 'node_clustering_user_study.mat';
eval(['load ../data/', dataset]);

node_cluster_map = zeros(length(nodes),1);
for i = 1:length(nodes);     
    node_cluster_map(i,1) = -1;
end;

for i = 1:length(node_clustering);     
    cluster_index_array = node_clustering{i};
    
    for j = 1: length(cluster_index_array);
        index = cluster_index_array(j);
        node_cluster_map(index,1) = i - 1;
    end;
       
end;

clear i j index cluster_index_array;
eval(['save ../data/', dataset]);
