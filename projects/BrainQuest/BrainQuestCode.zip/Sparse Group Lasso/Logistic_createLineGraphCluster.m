clear;

dataset = 'brain_logistic_small';
eval(['load ../data/', dataset]);

addpath(genpath(['./lib/MIT']));
poolobj = gcp;
addAttachedFiles(poolobj,{'./lib/MIT/newman_comm_fast.m'});

% define min threshold for edge features to use for clustering
value_threshold = 10;

% truncate edge features smaller than threshold
avg_edge_feature = mean(edge_feature, 1);
selected_feature_index = find(avg_edge_feature>=value_threshold);
selected_feature_count = size(selected_feature_index,2);

% create adjacency matrix
edgeAdj = zeros(selected_feature_count, selected_feature_count);

% fill adjacency matrix of selected edge features
for i = 1:selected_feature_count;
    selected_i_index = selected_feature_index(1,i);
    src_i_index = srcIndexMap(selected_i_index,1);
    dst_i_index = dstIndexMap(selected_i_index,1);
    
    for j = i+1:selected_feature_count;
        selected_j_index = selected_feature_index(1,j);
        src_j_index = srcIndexMap(selected_j_index,1);
        dst_j_index = dstIndexMap(selected_j_index,1);
        
        if (src_i_index == src_j_index) || (src_i_index == dst_j_index) || (dst_i_index == src_j_index) || (dst_i_index == dst_j_index);
%             edgeAdj(i, j) = abs(CCI_Ratio(1, selected_i_index) * CCI_Ratio(1, selected_j_index));
%             edgeAdj(j, i) = abs(CCI_Ratio(1, selected_i_index) * CCI_Ratio(1, selected_j_index));
            
            ratioI = CCI_Ratio(1, selected_i_index);
            ratioJ = CCI_Ratio(1, selected_j_index);
            edgeAdjValue = 1 - abs((ratioI - ratioJ)/max(ratioI, ratioJ));
            edgeAdj(i, j) = edgeAdjValue;
            edgeAdj(j, i) = edgeAdjValue;
        end;
        
    end;
end;

[groups_hist,Q]=newman_comm_fast(edgeAdj);

[maxQ, maxQ_index] = max(Q);
% maxQ_index = 64;
edge_clustering_by_line_JNI_minus = groups_hist{maxQ_index};
groups_hist_by_line_JNI_minus = groups_hist;
Q_by_line_JNI_minus = Q;

for i = 1:length(edge_clustering_by_line_JNI_minus);
    edge_clustering_by_line_JNI_minus{i} = selected_feature_index(1,edge_clustering_by_line_JNI_minus{i});
end;

%convert to original index
%edge_clustering = groups_hist{maxQ_index};

clear value_threshold avg_edge_feature selected_feature_index selected_feature_count;
clear maxQ maxQ_index Q groups_hist edgeAdj
clear i j selected_i_index selected_j_index src_i_index src_j_index dst_i_index dst_j_index
eval(['save ../data/', dataset]);


% define min threshold for edge features to use for clustering
value_threshold = 10;

% truncate edge features smaller than threshold
avg_edge_feature = mean(edge_feature, 1);
selected_feature_index = find(avg_edge_feature>=value_threshold);
selected_feature_count = size(selected_feature_index,2);

% create adjacency matrix
edgeAdj = zeros(selected_feature_count, selected_feature_count);

% fill adjacency matrix of selected edge features
for i = 1:selected_feature_count;
    selected_i_index = selected_feature_index(1,i);
    src_i_index = srcIndexMap(selected_i_index,1);
    dst_i_index = dstIndexMap(selected_i_index,1);
    
    for j = i+1:selected_feature_count;
        selected_j_index = selected_feature_index(1,j);
        src_j_index = srcIndexMap(selected_j_index,1);
        dst_j_index = dstIndexMap(selected_j_index,1);
        
        if (src_i_index == src_j_index) || (src_i_index == dst_j_index) || (dst_i_index == src_j_index) || (dst_i_index == dst_j_index);
%             edgeAdjValue = abs(avg_edge_feature(1, selected_i_index) * avg_edge_feature(1, selected_j_index));
%             edgeAdj(i, j) = edgeAdjValue;
%             edgeAdj(j, i) = edgeAdjValue;
            
            valueI = avg_edge_feature(1, selected_i_index);
            valueJ = avg_edge_feature(1, selected_j_index);
            edgeAdjValue = 1 - abs((valueI - valueJ)/max(valueI, valueJ));
            edgeAdj(i, j) = edgeAdjValue;
            edgeAdj(j, i) = edgeAdjValue;
        end;
        
    end;
end;

[groups_hist,Q]=newman_comm_fast(edgeAdj);

[maxQ, maxQ_index] = max(Q);
% maxQ_index = 64;
edge_clustering_by_line_strength_minus = groups_hist{maxQ_index};
groups_hist_by_line_strength_minus = groups_hist;
Q_by_line_strength_minus = Q;

for i = 1:length(edge_clustering_by_line_strength_minus);
    edge_clustering_by_line_strength_minus{i} = selected_feature_index(1,edge_clustering_by_line_strength_minus{i});
end;

%convert to original index
%edge_clustering = groups_hist{maxQ_index};

clear value_threshold avg_edge_feature selected_feature_index selected_feature_count;
clear maxQ maxQ_index Q groups_hist edgeAdj
clear i j selected_i_index selected_j_index src_i_index src_j_index dst_i_index dst_j_index
eval(['save ../data/', dataset]);



% define min threshold for edge features to use for clustering
value_threshold = 10;

% truncate edge features smaller than threshold
avg_edge_feature = mean(edge_feature, 1);
selected_feature_index = find(avg_edge_feature>=value_threshold);
selected_feature_count = size(selected_feature_index,2);

% create adjacency matrix
edgeAdj = zeros(selected_feature_count, selected_feature_count);

% fill adjacency matrix of selected edge features
for i = 1:selected_feature_count;
    selected_i_index = selected_feature_index(1,i);
    src_i_index = srcIndexMap(selected_i_index,1);
    dst_i_index = dstIndexMap(selected_i_index,1);
    
    for j = i+1:selected_feature_count;
        selected_j_index = selected_feature_index(1,j);
        src_j_index = srcIndexMap(selected_j_index,1);
        dst_j_index = dstIndexMap(selected_j_index,1);
        
        if (src_i_index == src_j_index) || (src_i_index == dst_j_index) || (dst_i_index == src_j_index) || (dst_i_index == dst_j_index);
            edgeAdjValue = abs(avg_edge_feature(1, selected_i_index) * avg_edge_feature(1, selected_j_index));
            edgeAdj(i, j) = edgeAdjValue;
            edgeAdj(j, i) = edgeAdjValue;
            
%             valueI = avg_edge_feature(1, selected_i_index);
%             valueJ = avg_edge_feature(1, selected_j_index);
%             edgeAdjValue = 1 - abs((valueI - valueJ)/max(valueI, valueJ));
%             edgeAdj(i, j) = edgeAdjValue;
%             edgeAdj(j, i) = edgeAdjValue;
        end;
        
    end;
end;

[groups_hist,Q]=newman_comm_fast(edgeAdj);

[maxQ, maxQ_index] = max(Q);
% maxQ_index = 64;
edge_clustering_by_line_strength_multi = groups_hist{maxQ_index};
groups_hist_by_line_strength_multi = groups_hist;
Q_by_line_strength_multi = Q;

for i = 1:length(edge_clustering_by_line_strength_multi);
    edge_clustering_by_line_strength_multi{i} = selected_feature_index(1,edge_clustering_by_line_strength_multi{i});
end;

%convert to original index
%edge_clustering = groups_hist{maxQ_index};

clear value_threshold avg_edge_feature selected_feature_index selected_feature_count;
clear maxQ maxQ_index Q groups_hist edgeAdj
clear i j selected_i_index selected_j_index src_i_index src_j_index dst_i_index dst_j_index
eval(['save ../data/', dataset]);